# setup.py
from setuptools import setup, find_packages

setup(
    name='sample',
    packages=find_packages()
)